local M = {}

local TOTAL_BULLETS = 48    
local SPREAD_RADIUS = 0.8   

function M.calcSpread(api, ammoCnt, basicInaccuracy)
    local cache = api:getCachedScriptData() or {}
    local is_second_shot = cache.is_second_shot or false

    local safe_ammoCnt = ammoCnt % TOTAL_BULLETS

    local scale = 1.0
    local progress = 0.0 

    if safe_ammoCnt < 3 then
        scale = 0.25
        progress = safe_ammoCnt / 3
    elseif safe_ammoCnt < 12 then
        scale = 0.50
        progress = (safe_ammoCnt - 3) / 9
    elseif safe_ammoCnt < 27 then
        scale = 0.75
        progress = (safe_ammoCnt - 12) / 15
    else
        scale = 1.00
        progress = (safe_ammoCnt - 27) / 21
    end

    local yaw = 0   
    local pitch = 0 

    if not is_second_shot then
        local side = math.floor(progress * 3) 
        if side > 2 then side = 2 end 
        local step = (progress * 3) - side

        local pt0_yaw, pt0_pitch = 0, SPREAD_RADIUS                      
        local pt1_yaw, pt1_pitch = SPREAD_RADIUS * 0.866, -SPREAD_RADIUS * 0.5   
        local pt2_yaw, pt2_pitch = -SPREAD_RADIUS * 0.866, -SPREAD_RADIUS * 0.5  

        if side == 0 then
            yaw = pt0_yaw + (pt1_yaw - pt0_yaw) * step
            pitch = pt0_pitch + (pt1_pitch - pt0_pitch) * step
        elseif side == 1 then
            yaw = pt1_yaw + (pt2_yaw - pt1_yaw) * step
            pitch = pt1_pitch + (pt2_pitch - pt1_pitch) * step
        else
            yaw = pt2_yaw + (pt0_yaw - pt2_yaw) * step
            pitch = pt2_pitch + (pt0_pitch - pt2_pitch) * step
        end
    else
        local angle = progress * 2 * math.pi
        yaw = SPREAD_RADIUS * math.cos(angle)
        pitch = SPREAD_RADIUS * math.sin(angle)
    end

    yaw = yaw * scale
    pitch = pitch * scale

    return {yaw, pitch}
end

function M.shoot(api)
    local cache = api:getCachedScriptData() or {}
    
    api:shootOnce(api:isShootingNeedConsumeAmmo())
    
    cache.is_second_shot = not (cache.is_second_shot or false)
    api:cacheScriptData(cache)
end

function M.start_reload(api)
    local cache = api:getCachedScriptData() or {}
    cache.is_second_shot = false 
    cache.is_tactical = (api:getReloadStateType() == TACTICAL_RELOAD_FEEDING)
    api:cacheScriptData(cache)
    return true
end

function M.tick_reload(api)
    local cache = api:getCachedScriptData()
    if not cache then return NOT_RELOADING, -1 end
    
    local reload_time = api:getReloadTime()
    local power_feed = 1830 
    local power_close = 2300 
    
    if cache.is_tactical then
        power_feed = 1230
        power_close = 1600
    end

    if (reload_time < power_feed) then
        return TACTICAL_RELOAD_FEEDING, power_feed - reload_time
    elseif (reload_time >= power_feed and reload_time < power_close) then
        api:putAmmoInMagazine(2) 
        return TACTICAL_RELOAD_FINISHING, power_close - reload_time
    else
        return NOT_RELOADING, -1
    end
end

return M